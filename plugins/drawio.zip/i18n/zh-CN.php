<?php
return array(
	'drawio.menu'        					=> "流程图",
    'drawio.meta.name'         				=> "Drawio流程图",
	'drawio.meta.title'        				=> "流程图绘制工具",
	'drawio.meta.desc'						=> "drawio流程图绘制",	
	
	'drawio.config.settingMore'				=> "高级设置",
	'drawio.config.staticCDN'				=> "静态资源CDN",
	'drawio.config.staticCDN.desc'			=> "默认关闭,静态url同站点url",
	'drawio.config.staticCDNPath'			=> "资源CDN的url路径",
	'drawio.config.staticCDNPath.desc'		=> "默认放到站点cdn的static/plugins/ 下;则不用指定; 指定到",
	'drawio.config.iconSearch'				=> "图标网络搜索源",
	'drawio.config.iconSearch.desc'			=> "搜索图标时,网络图标搜索源设置; 搜索结果会有不同;阿里icon对中文搜索更友好",
	'drawio.config.staticSearchProxy'		=> "网络请求方式",
	'drawio.config.staticSearchProxy.no'	=> "前端直接请求",
	'drawio.config.staticSearchProxy.yes'	=> "后端代理请求",
);