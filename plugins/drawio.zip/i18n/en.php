<?php
return array(
	'drawio.menu'        					=> "Diagram",
    'drawio.meta.name'         				=> "Drawio diagram",
	'drawio.meta.title'        				=> "Diagram tool",
	'drawio.meta.desc'						=> "Drawio diagram",	
	
	'drawio.config.settingMore'				=> "Advanced setting",
	'drawio.config.staticCDN'				=> "Static resource CDN",
	'drawio.config.staticCDN.desc'			=> "By default, the static URL is the same as the site URL",
	'drawio.config.staticCDNPath'			=> "URL path of resource CDN",
	'drawio.config.staticCDNPath.desc'		=> "It is placed under static / plugins / of CDN by default; It does not need to be specified; Assign to",
	'drawio.config.iconSearch'				=> "Icon web search source",
	'drawio.config.iconSearch.desc'			=> "When searching for icons, the network icon search source is set; The search results will be different; Aliicon is more friendly to Chinese search",
	'drawio.config.staticSearchProxy'		=> "Network request mode",
	'drawio.config.staticSearchProxy.no'	=> "Front end direct request",
	'drawio.config.staticSearchProxy.yes'	=> "Back end proxy request",
);